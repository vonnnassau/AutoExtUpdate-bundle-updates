'use strict';

/* export const ns = config.id;
export const company = config.zxp.org;
export const displayName = config.displayName;
export const version = config.version; */

const ns = "com.bolt-update-one.cep";

const helloWorld$1 = () => {
  var comp = app.project.activeItem;
  if (comp && comp instanceof CompItem) {
    app.beginUndoGroup("Add Hello Layer");
    var textLayer = comp.layers.addText("Updated jsx from After Effects!");
    textLayer.name = "martians";
    app.endUndoGroup();
    return "✅ Text layer added";
  } else {
    return "⚠️ No active comp selected";
  }
};
const createLayer = () => {
  var comp = app.project.activeItem;
  if (comp && comp instanceof CompItem) {
    app.beginUndoGroup("Add Hello Layer");
    var textLayer = comp.layers.addText("Another Layer");
    textLayer.name = "Another";
    app.endUndoGroup();
    return "✅ Text layer added";
  } else {
    return "⚠️ No active comp selected";
  }
};
const testAlert = () => {
  alert("1This is a test alert from AEFT!");
};
///
$.writeln("ExtendScript (JSX) bundle loaded and running");

var aeft = /*#__PURE__*/Object.freeze({
  __proto__: null,
  createLayer: createLayer,
  helloWorld: helloWorld$1,
  testAlert: testAlert
});

const helloVoid = () => {
  alert("test");
};
const helloError = str => {
  // Intentional Error for Error Handling Demonstration
  //@ts-ignore
  throw new Error(`We're throwing an error`);
};
const helloStr = str => {
  alert(`ExtendScript received a string: ${str}`);
  return str;
};
const helloNum = n => {
  alert(`ExtendScript received a number: ${n.toString()}`);
  return n;
};
const helloArrayStr = arr => {
  alert(`ExtendScript received an array of ${arr.length} strings: ${arr.toString()}`);
  return arr;
};
const helloObj = obj => {
  alert(`ExtendScript received an object: ${JSON.stringify(obj)}`);
  return {
    y: obj.height,
    x: obj.width
  };
};

const helloWorld = () => {
  alert("Hello from Illustrator");
};

var ilst = /*#__PURE__*/Object.freeze({
  __proto__: null,
  helloArrayStr: helloArrayStr,
  helloError: helloError,
  helloNum: helloNum,
  helloObj: helloObj,
  helloStr: helloStr,
  helloVoid: helloVoid,
  helloWorld: helloWorld
});

// @include './lib/json2.js'


//@ts-ignore
const host = typeof $ !== "undefined" ? $ : window;

// A safe way to get the app name since some versions of Adobe Apps broken BridgeTalk in various places (e.g. After Effects 24-25)
// in that case we have to do various checks per app to deterimine the app name

const getAppNameSafely = () => {
  const compare = (a, b) => {
    return a.toLowerCase().indexOf(b.toLowerCase()) > -1;
  };
  const exists = a => typeof a !== "undefined";
  const isBridgeTalkWorking = typeof BridgeTalk !== "undefined" && typeof BridgeTalk.appName !== "undefined";
  if (isBridgeTalkWorking) {
    return BridgeTalk.appName;
  } else if (app) {
    //@ts-ignore
    if (exists(app.name)) {
      //@ts-ignore
      const name = app.name;
      if (compare(name, "photoshop")) return "photoshop";
      if (compare(name, "illustrator")) return "illustrator";
      if (compare(name, "audition")) return "audition";
      if (compare(name, "bridge")) return "bridge";
      if (compare(name, "indesign")) return "indesign";
    }
    //@ts-ignore
    if (exists(app.appName)) {
      //@ts-ignore
      const appName = app.appName;
      if (compare(appName, "after effects")) return "aftereffects";
      if (compare(appName, "animate")) return "animate";
    }
    //@ts-ignore
    if (exists(app.path)) {
      //@ts-ignore
      const path = app.path;
      if (compare(path, "premiere")) return "premierepro";
    }
    //@ts-ignore
    if (exists(app.getEncoderHost) && exists(AMEFrontendEvent)) {
      return "ame";
    }
  }
  return "unknown";
};
switch (getAppNameSafely()) {
  case "aftereffects":
  case "aftereffectsbeta":
    host[ns] = aeft;
    break;
  case "illustrator":
  case "illustratorbeta":
    host[ns] = ilst;
    break;
}
// prettier-ignore

// https://extendscript.docsforadobe.dev/interapplication-communication/bridgetalk-class.html?highlight=bridgetalk#appname
